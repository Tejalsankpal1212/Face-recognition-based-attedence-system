  var deptId="";
   // Get the modal
   var modal = $('#modalDialog');
        
   // Get the button that opens the modal
   var createBtn = $("#createBtn");
   
   // Get the <span> element that closes the modal
   var span = $(".close");

   var submitBtn=$(".submit");

   function GetDepartments()
   {
    //Get the data from database and Bind to the table
     
        axios.get('http://127.0.0.1:8001/department/getalldepartments')
        .then(res=>{
              console.log(res.data.payload);
              return res.data.payload;
        }).then((deptdata)=>{
         var table = document.getElementById("department-table-body");
         table.innerHTML="";
         for (let index = 0; index < deptdata.length; index++) {
           var row = ` <tr>
                          <td hidden>
                             <p>${deptdata[index].dept_id}</p>
                          </td>
                          <td>
                             <p>${deptdata[index].dept_name}</p>
                          </td>
                          <td>
                            <div>
                            <button class="edit" onClick="UpdateDeptartment(this)">Edit</button>
                            <button class="delete" onClick="DeleteDepartment(this)">Delete</button>
                            <div>
                          </td>
                       </tr>
                     `
           table.innerHTML+=row;
         }
         console.log(deptdata.length)
         document.getElementById("count").innerHTML = `| ${deptdata.length} Departments`;
        })
        .catch(err=>{
         console.log(err);
        })
   }

   function UpdateDeptartment(row)
   {
      deptId=row.parentElement.parentElement.parentElement.cells[0].children[0].innerHTML
      document.getElementById("deptName").value=row.parentElement.parentElement.parentElement.cells[1].children[0].innerHTML
      document.getElementById("submitBtn").textContent="Update"
      modal.show();
      console.log(deptId);
      GetDepartments();
   }

   function DeleteDepartment(row)
   {
      var deptid=row.parentElement.parentElement.parentElement.cells[0].children[0].innerHTML

      try {
            const res =  axios.delete('http://127.0.0.1:8001/department/deletedepartment/'+deptid);
            const result = res;        
            console.log(res);
          } 
      catch (errors) 
          {
            console.error(errors);
          }          
      GetDepartments();
   }

   $(document).ready(function(){

      GetDepartments();
      
       // When the user clicks the button, open the modal 
       createBtn.on('click', function() 
       {
          document.getElementById("submitBtn").textContent="Submit"
          modal.show();
       });
       
       // When the user clicks on <span> (x), close the modal
       span.on('click', function() 
       {
           modal.hide();
       });

       submitBtn.on('click', function()
       {
          var deptName=document.getElementById("deptName").value;
          if(deptId!="")
          {
          const dept={
            "deptid":deptId,
            "deptname":deptName
          };

          try {
                const res =  axios.put('http://127.0.0.1:8001/department/putdepartment', dept);
                const result = res;        
                console.log(res);
              } 
          catch (errors) 
              {
                console.error(errors);
              }
          
          GetDepartments();
          modal.hide();
           
        }
        else
        {
         const dept={
            "deptname":deptName
         };

         try {
                const res =  axios.post('http://127.0.0.1:8001/department/postdepartment', dept);
                const result = res;        
                console.log(res);
              } 
          catch (errors) 
              {
                console.error(errors);
              }
          
          GetDepartments();
          modal.hide();

            }
        });
       
   });
   