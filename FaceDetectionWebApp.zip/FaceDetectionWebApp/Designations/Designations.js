   
   var designId="";
   // Get the modal
   var modal = $('#modalDialog');
        
   // Get the button that opens the modal
   var btn = $("#createBtn");
   
   // Get the <span> element that closes the modal
   var span = $(".close");

   var submitBtn=$(".submit");

   
   function GetDepartments()
   {
    //Get the data from database and Bind to the table
    
        axios.get('http://127.0.0.1:8001/department/getalldepartments')
        .then(res=>{
                    console.log(res.data.payload);
                    return res.data.payload;
                    }).then((deptdata)=>{
                                var select = document.getElementById("deptName");
                                select.innerHTML="<option hidden>Select department</option>";
                                for (let index = 0; index < deptdata.length; index++) 
                                {
                                    var option = `<option value="${deptdata[index].dept_id}">${deptdata[index].dept_name}</option>`
                                    select.innerHTML+=option;
                                }
                                })
        .catch(err=>{
         console.log(err);
        })
   }


   function GetDesignations()
   {
        //Get the data from database and Bind to the table
    
        axios.get('http://127.0.0.1:8001/designation/getalldesignations')
        .then(res=>{
              console.log(res.data.payload);
              return res.data.payload;
        }).then((designdata)=>{
         var table = document.getElementById("designation-table-body");
         
         table.innerHTML="";
         for (let index = 0; index < designdata.length; index++) {
           var row = ` <tr>
                          <td hidden>
                             <p>${designdata[index].design_id}</p>
                          </td>
                          <td>
                             <p>${designdata[index].design_name}</p>
                          </td>
                          <td>
                             <p>${designdata[index].dept_name}</p>
                          </td>
                          <td>
                            <div>
                            <button class="edit" onClick="UpdateDesignation(this)">Edit</button>
                            <button class="delete" onClick="DeleteDesignation(this)">Delete</button>
                            <div>
                          </td>
                       </tr>
                     `
           table.innerHTML+=row;
         }

         document.getElementById("count").innerHTML = `| ${designdata.length} Designations`;
        })
        .catch(err=>{
         console.log(err);
        })
   }

   function UpdateDesignation(row)
   {
      designId=row.parentElement.parentElement.parentElement.cells[0].children[0].innerHTML
      document.getElementById("designName").value=row.parentElement.parentElement.parentElement.cells[1].children[0].innerHTML
      document.getElementById("deptName").value=row.parentElement.parentElement.parentElement.cells[2].children[0].innerHTML
      document.getElementById("submitBtn").textContent="Update"
      modal.show();
      console.log(desigId);
   }

   function DeleteDesignation(row)
   {
      var desigid=row.parentElement.parentElement.parentElement.cells[0].children[0].innerHTML

      try {
            const res =  axios.delete('http://127.0.0.1:8001/designation/deletedesignation/'+desigid);
            const result = res;        
            console.log(res);
          } 
      catch (errors) 
          {
            console.error(errors);
          }          
        GetDesignations();
   }



   $(document).ready(function(){

        GetDepartments();
        GetDesignations();


       // When the user clicks the button, open the modal 
       btn.on('click', function() {
           modal.show();
       });
       
       // When the user clicks on <span> (x), close the modal
       span.on('click', function() {
           modal.hide();
       });

       submitBtn.on('click', function()
       {
            const result =[];
            var designName=document.getElementById("designName").value;
            var deptId=document.getElementById("deptName").value;
            if(designId!="")
            {
                const design={
                "designid":designId,
                "designname":designName,
                "deptid":deptId
                };

                // try {
                //     const res =  axios.put('http://127.0.0.1:8001/designation/putdesignation', design);
                //     result = res;        
                //     console.log(res);
                //     } 
                // catch (errors) 
                //     {
                //     console.error(errors);
                //     }

                    try {
                        axios.put('http://127.0.0.1:8001/designation/putdesignation', design)
                        .then(res=>{
                                    return res.data.message;
                                    }).then((msg)=>
                                    {
                                        swal({
                                            text: msg,
                                            icon: "success"
                                        }); 
                                    });
                    } 
                catch (errors) 
                    {
                        //console.error(errors);
                    }
                
                    setTimeout(()=>{
                        GetDepartments();
                        GetDesignations();
                        },3000);
            }
            else
            {
                const design= {
                                "designname":designName,
                                "deptid":deptId
                             };

                // try {
                //         const res =  axios.post('http://127.0.0.1:8001/designation/postdesignation', design);
                //         result = res;        
                //         console.log(res);
                //         } 
                // catch (errors) 
                //         {
                //         console.error(errors);
                //         }

                        try {
                            axios.post('http://127.0.0.1:8001/designation/postdesignation', design)
                            .then(res=>{
                                        return res.data.message;
                                        }).then((msg)=>
                                        {
                                            swal({
                                                text: msg,
                                                icon: "success"
                                            }); 
                                        });
                        } 
                    catch (errors) 
                        {
                            //console.error(errors);
                        }
                    
                        setTimeout(()=>{
                            GetDepartments();
                            GetDesignations();
                            },3000);
            }                
               
                modal.hide();

            });
   });
  