
function GetAttendance()
{
 //Get the data from database and Bind to the table
 
     axios.get('http://127.0.0.1:8001/attendance/gettodaysattendance')
     .then(res=>{
                 //console.log(res.data.payload);
                 return res.data.payload;
                 }).then((attdata)=>{
                             var table = document.getElementById("attendance-table-body");
                             table.innerHTML="";
                             for (let index = 0; index < attdata.length; index++) 
                             {
                                 var row = `<tr>
                                 <td hidden>
                                     <p>${attdata[index].emp_id}</p>
                                 </td>
                                 
                                 <td>
                                     <p>${attdata[index].empname}</p>
                                 </td>
                                 <td>
                                     <p>${attdata[index].date}</p>
                                 </td>                                       
                               
                                 <td>
                                     <p>${attdata[index].time}</p>
                                 </td>
                                
                             </tr>
                             `  
                             table.innerHTML+=row;
                             }

                             document.getElementById("count").innerHTML = `| ${attdata.length} Attendance`;

                             })
     .catch(err=>{
      //console.log(err);
     })
}

$(document).ready(function(){
  GetAttendance();
});