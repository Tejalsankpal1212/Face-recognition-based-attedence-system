const body = document.querySelector('body'),
sidebar = body.querySelector('nav'),
toggle = body.querySelector(".toggle"),
modeSwitch = body.querySelector(".toggle-switch"),
modeText = body.querySelector(".mode-text");

let getMode=localStorage.getItem("mode")

if(getMode && getMode=="dark"){
    body.classList.toggle("dark");
    toggle.classList.toggle("active");
}

toggle.addEventListener("click" , () =>{
  sidebar.classList.toggle("close");
})

modeSwitch.addEventListener("click" , () =>{
    body.classList.toggle("dark");
    
    if(body.classList.contains("dark")){
      modeText.innerText = "Light mode";
    }else{
      modeText.innerText = "Dark mode";
    }

    if(!body.classList.contains("dark")){
        return  localStorage.setItem("mode","light")
      }
      else{
          return  localStorage.setItem("mode","dark")
      }
    });

toggle.addEventListener("click" , () =>{
    toggle.classList.toggle("active");
    })
   

    