        var empId="";
        var base64ImageSource="";
        var imgsrc;
        // Get the modal
        var modal = $('#modalDialog');
        
        // Get the button that opens the modal
        var btn = $("#createBtn");
        
        // Get the <span> element that closes the modal
        var span = $(".close");

        var submitBtn=$(".submit");

        var imgBtn=$(".imgBtn");

       let ImageInput=$("#imgFile");

   function UpdateEmployee(row)
   {
      GetDesignations();
      empId=row.parentElement.parentElement.parentElement.cells[0].children[0].innerHTML;
      document.getElementById("FullName").value=row.parentElement.parentElement.parentElement.cells[1].children[1].children[0].innerHTML;
      document.getElementById("EmailAddress").value=row.parentElement.parentElement.parentElement.cells[3].children[0].innerHTML;
      document.getElementById("PhoneNumber").value=row.parentElement.parentElement.parentElement.cells[5].children[0].innerHTML;
      document.getElementById("Birthdate").value= new Date(row.parentElement.parentElement.parentElement.cells[4].children[0].innerHTML);
      document.getElementById("AddressLine1").value=row.parentElement.parentElement.parentElement.cells[6].children[0].innerHTML;
      document.getElementById("AddressLine2").value=row.parentElement.parentElement.parentElement.cells[7].children[0].innerHTML;
      document.getElementById("City").value=row.parentElement.parentElement.parentElement.cells[10].children[0].innerHTML;
      document.getElementById("Country").value=row.parentElement.parentElement.parentElement.cells[8].children[0].innerHTML;
      document.getElementById("designName").value=row.parentElement.parentElement.parentElement.cells[11].children[0].innerHTML;
      document.getElementById("PostalCode").value=row.parentElement.parentElement.parentElement.cells[9].children[0].innerHTML;
      document.getElementById("PostalCode").value=row.parentElement.parentElement.parentElement.cells[9].children[0].innerHTML;
      var img=row.parentElement.parentElement.parentElement.cells[1].children[0].children[0];
      document.getElementById("photoImg").src=img.src;
                //photoimg.src=src;
      //console.log(row.parentElement.parentElement.parentElement.cells[9].children[0].innerHTML);
      if (row.parentElement.parentElement.parentElement.cells[2].children[0].innerHTML=="M")
      {
            var maleCheck=document.getElementById("check-male");
            maleCheck.checked=true;
      }
      else if (row.parentElement.parentElement.parentElement.cells[2].children[0].innerHTML=="F")
      {
            var femaleCheck=document.getElementById("check-female");
            femaleCheck.checked=true;
      } 
      else
      {
            var otherCheck=document.getElementById("check-other");
            otherCheck.checked=true;
      } 

      document.getElementById("submitBtn").textContent="Update"
      modal.show();
   }

   function DeleteEmployee(row)
   {
      var empid=row.parentElement.parentElement.parentElement.cells[0].children[0].innerHTML;
        console.log(empid);
      try {
           axios.delete('http://127.0.0.1:8001/employee/deleteemployee/'+empid)
           .then(res=>{
            return res.data.message;
            }).then((msg)=>
            {
                swal({
                    text: msg,
                    icon: "success"
                }); 
            });

            setTimeout(()=>{
                GetDesignations();
                GetEmployees();
                },3000);

          } 
      catch (errors) 
          {
            console.error(errors);
          }          
      
   }

       

       function GetDesignations()
       {
        //Get the data from database and Bind to the table
        
            axios.get('http://127.0.0.1:8001/designation/getalldesignations')
            .then(res=>{
                        //console.log(res.data.payload);
                        return res.data.payload;
                        }).then((designdata)=>{
                                    var select = document.getElementById("designName");
                                    select.innerHTML="<option hidden>Select designation</option>";
                                    for (let index = 0; index < designdata.length; index++) 
                                    {
                                        //console.log(designdata);
                                        var option = `<option value="${designdata[index].design_id}">${designdata[index].design_name}</option>`
                                        select.innerHTML+=option;
                                    }
                                    })
            .catch(err=>{
             //console.log(err);
            })
       }


       function GetEmployees()
       {
        //Get the data from database and Bind to the table
        
            axios.get('http://127.0.0.1:8001/employee/getallemployees')
            .then(res=>{
                        //console.log(res.data.payload);
                        return res.data.payload;
                        }).then((empdata)=>{
                                    var table = document.getElementById("employee-table-body");
                                    table.innerHTML="";
                                    for (let index = 0; index < empdata.length; index++) 
                                    {
                                        //console.log(empdata[index].empname);
                                        var row = `<tr>
                                        <td hidden>
                                            <p>${empdata[index].emp_id}</p>
                                        </td>
                                        <td class="member">
                                            <figure><img src="http://127.0.0.1:8001/resources/employees/${empdata[index].photo}" /></figure>
                                            <div class="member-info">
                                                <p>${empdata[index].empname}</p>
                                            </div>
                                        </td>
                                        <td>
                                            <p>${empdata[index].gender}</p>
                                        </td>
                                        <td>
                                            <p>${empdata[index].emailid}</p>
                                        </td>                                       
                                        <td>
                                            <p>${new Date(empdata[index].dateofbirth).toDateString()}</p>
                                        </td>
                                        <td>
                                            <p>${empdata[index].phonenumber}</p>
                                        </td>
                                        <td hidden>
                                            <p>${empdata[index].addressline1}</p>
                                        </td>
                                        <td hidden>
                                            <p>${empdata[index].addressline2}</p>
                                        </td>
                                        <td hidden>
                                            <p>${empdata[index].country}</p>
                                        </td>
                                        <td hidden>
                                            <p>${empdata[index].postalcode}</p>
                                        </td>
                                        <td>
                                            <p>${empdata[index].city}</p>
                                        </td>
                                        <td>
                                        <p>${empdata[index].designname}</p>
                                        </td>
                                        <td>
                                            <div class="action">
                                            <button class="edit" onClick="UpdateEmployee(this)">Edit</button>
                                            <button class="delete" onClick="DeleteEmployee(this)">Delete</button>
                                            <div>
                                        </td>
                                    </tr>
                                    `
                                    table.innerHTML+=row;
                                    }
                            
                                    document.getElementById("count").innerHTML = `| ${empdata.length} Employees`;
                                  
                                    })
            .catch(err=>{
             //console.log(err);
            })
       }
       
       
        $(document).ready(function(){

            GetDesignations();
            GetEmployees();
            
            // When the user clicks the button, open the modal 
            btn.on('click', function() {
                modal.show();
            });
            
            // When the user clicks on <span> (x), close the modal
            span.on('click', function() {
                modal.hide();
            });

            imgBtn.on('click', function()
                {
                    ImageInput.click();
                });

            ImageInput.on('change',function(event){
               if(event.target.files.length>0)
               {
                imgsrc=event.target.files[0];
                var src=URL.createObjectURL(event.target.files[0]);
                const reader= new FileReader();
                reader.readAsDataURL(event.target.files[0]);
                reader.onloadend = function() {
                    base64ImageSource= reader.result;
                  }
                var photoimg=document.getElementById("photoImg");
                photoimg.src=src;
               // console.log(base64ImageSource);
               }
            });
            
            submitBtn.on('click', function()
            {
                var empName=document.getElementById("FullName").value;
                var emailId=document.getElementById("EmailAddress").value;
                var empPhoto=base64ImageSource;
                var phoneNumber=document.getElementById("PhoneNumber").value;
                var birthDate=document.getElementById("Birthdate").value;
                var genderelements=document.getElementsByName("gender");
                var gender="";
                
                genderelements.forEach(element => {
                    if(element.checked)
                    {
                        // console.log(element.value);
                        gender=element.value;
                    }
                });

                var addressLine1=document.getElementById("AddressLine1").value;
                var addressLine2=document.getElementById("AddressLine2").value;
                var country=document.getElementById("Country").value;
                var city=document.getElementById("City").value;
                var designId=document.getElementById("designName").value;
                // console.log(designId);
                var postalCode=document.getElementById("PostalCode").value;

                if(empId!="")
                {
                    const formdata=new FormData();
                    formdata.append("empid",empId);
                        formdata.append("empname",empName);
                        formdata.append("emailid",emailId);
                        formdata.append("empphoto",imgsrc);
                        formdata.append("phonenumber",phoneNumber);
                        formdata.append("birthdate",birthDate);
                        formdata.append("gender",gender);
                        formdata.append("addressline1",addressLine1);
                        formdata.append("addressline2",addressLine2);
                        formdata.append("country",country);
                        formdata.append("city",city);
                        formdata.append("postalcode",postalCode);
                        formdata.append("designid",designId);

                    try {
                            axios.put('http://127.0.0.1:8001/employee/putemployee', formdata)
                            .then(res=>{
                                        return res.data.message;
                                        }).then((msg)=>
                                        {
                                            swal({
                                                text: msg,
                                                icon: "success"
                                            }); 
                                        });
                        } 
                    catch (errors) 
                        {
                            //console.error(errors);
                        }
                    
                        setTimeout(()=>{
                            GetDesignations();
                            GetEmployees();
                            },3000);
                           
                    modal.hide();
                    
                }
                else
                {
               
                    const formdata=new FormData();
                        formdata.append("empname",empName);
                        formdata.append("emailid",emailId);
                        formdata.append("empphoto",imgsrc);
                        formdata.append("phonenumber",phoneNumber);
                        formdata.append("birthdate",birthDate);
                        formdata.append("gender",gender);
                        formdata.append("addressline1",addressLine1);
                        formdata.append("addressline2",addressLine2);
                        formdata.append("country",country);
                        formdata.append("city",city);
                        formdata.append("postalcode",postalCode);
                        formdata.append("designid",designId);

                    try {
                           
                            axios.post('http://127.0.0.1:8001/employee/postemployee', formdata)
                            .then(function (response) {
                                return response.data.message;
                              })
                              .then((msg)=>
                                        {
                                            swal({
                                                text: msg,
                                                icon: "success"
                                            }); 
                                        });
                          
                        } 
                    catch (errors) 
                        {
                            console.error(errors);
                        }

                    setTimeout(()=>{
                        GetDesignations();
                        GetEmployees();
                        },3000);
                       
                    modal.hide();
                }
            });

        });
       
       